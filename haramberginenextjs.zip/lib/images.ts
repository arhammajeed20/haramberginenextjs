// Logo
import heroimage from "@/public/heroimage.png";
import whoimage from "@/public/whoimage.png";

export { heroimage, whoimage };
